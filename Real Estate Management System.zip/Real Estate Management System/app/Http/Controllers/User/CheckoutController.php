<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CheckoutController extends Controller
{
    public function create()
    {
        return view('user.checkout.create');
    }

    public function all_order()
    {
        $carts = Cart::where('user_id', Auth::id())->get();
        return view('user.checkout.details', compact('carts'));
    }

    public function update($id, Request $request)
    {
        $update = Cart::find($id);
        $update['quantity']= $request->quantity;
        $update->save();
        return back();
    }


    public function checkout_store(Request $request)
    {

        $order = new Order;
        $order->name = $request->name;
        $order->email = $request->email;
        $order->phone = $request->phone;
        $order->location = $request->location;
        $order->description = $request->description;
        $order->user_id = Auth::id();
        $order->save();
        foreach (Cart::item_cart() as $cart) {
            $cart['order_id']=$order->id;
            $cart->save();
    }
    return redirect('/');

    }
}
