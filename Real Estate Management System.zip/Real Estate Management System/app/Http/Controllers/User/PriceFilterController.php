<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;

class PriceFilterController extends Controller
{
    public function filter(Request $request)
    {

        $properties = Property::all();

           $properties =  $properties->where('price', '<=', $request->max_price);//minimum price


        return view('user.search', compact('properties'));
    }
}
