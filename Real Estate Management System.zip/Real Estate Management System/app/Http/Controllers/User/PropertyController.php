<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;

class PropertyController extends Controller
{
    public function land()
    {
        $properties = Property::where('land_id',!Null)->where('status', 1)->get();
        return view('user.property.index', compact('properties'));
    }

    public function house()
    {
        $properties = Property::where('house_id',!Null)->where('status', 1)->get();
        return view('user.property.index', compact('properties'));
    }
}
