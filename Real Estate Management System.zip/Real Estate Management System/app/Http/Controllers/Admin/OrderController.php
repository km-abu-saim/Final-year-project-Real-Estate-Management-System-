<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(){
        $orders = Order::all();
        return view('admin.order.list', compact('orders'));
    }

    public function status($id)
    {
        $status = Order::find($id);
        if($status->status == 1){
            $status['status'] = 0;
            $status->save();
            return back();
        }else{
            $status['status'] = 1;
            $status->save();
            return back();
        }
    }

    public function detail($id){
        $checkout = Order::find($id);
        return view('admin.order.detail', compact('checkout'));
    }

    public function cart_delete($id)
    {
        Cart::find($id)->delete();
        return back();
    }
    public function delete($id)
    {
        Order::find($id)->delete();
        return back();
    }
}
