<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
USE Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function create()
    {
        $user = User::find(Auth::id());
        return view('admin.profile.create', compact('user'));
    }

    public function store($id, Request $request)
    {
        $user = User::find($id);
        $user['name'] = $request->name;
        $user['email'] = $request->email;
        $user->save();
        return redirect()->route('admin.dashboard');
    }

}
