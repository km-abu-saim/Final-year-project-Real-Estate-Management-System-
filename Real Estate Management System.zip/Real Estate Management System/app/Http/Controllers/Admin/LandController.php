<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Land;
use Illuminate\Http\Request;

class LandController extends Controller
{public function index()
    {
        $Lands = Land::all(['id', 'name', 'status']);
        return view('admin.land.index', compact('Lands'));
    }

    public function validation($request)
    {
        $request->validate([
            'name' => 'required | max:30 | min: 2',
        ]);
    }


    public function save(land $land, Request $request)
    {
        $land['name'] = $request->name;
        $land->save();
    }

    public function store($id = null, Request $request)
    {
        if (isset($id)) {
            $land = Land::find($id);
            $this->validation($request);
            $this->save($land, $request);
            return back();
        } else {
            $land = new Land;
            $this->validation($request);
            $this->save($land, $request);
            return back();
        }
    }

    public function edit($id)
    {
        $edit = Land::find($id);
        $Lands = Land::all(['id', 'name', 'status']);
        return view('admin.land.index', compact('edit', 'Lands'));
    }


    public function status($id)
    {
        $land = Land::find($id);
        if($land->status == 1){
            $land['status'] = 0;
            $land->save();
            return back();
        }else{
            $land['status'] = 1;
            $land->save();
            return back();
        }
    }
    public function destroy($id)
    {
        Land::find($id)->delete();
        return back();
    }
}
