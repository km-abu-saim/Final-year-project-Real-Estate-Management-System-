<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Constractor;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ConstractorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $constractors = Constractor::all();
        return view('admin.constractor.index', compact('constractors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.constractor.create');
    }

    public function save(Constractor $constractor, Request $request)
    {
        $constractor['name'] = $request->name;
        $constractor['phone'] = $request->phone;
        $constractor['email'] = $request->email;
        $constractor['address'] = $request->address;
        $constractor['exp'] = $request->exp;
        $constractor['rate'] = $request->rate;
        $constractor['total_project'] = $request->total_project;
        $constractor['availity'] = $request->availity;
        $constractor['url'] = $request->url;


        if($request->image){

            $image=$request->file('image');
            if ($image){
            $image_name=Str::random(20);
            $ext=strtolower($image->getClientOriginalExtension());
            $image_full_name=$image_name.'.'.$ext;
            $upload_path='image/';
            $image_url=$upload_path.$image_full_name;
            $success=$image->move($upload_path,$image_full_name);
                if ($success) {
                $constractor['image']=$image_url;

                 }
             }
        }else{
            $constractor['image'] = $constractor->image;
        }

        $constractor->save();
    }

    public function storeOrUpdate($id =null ,Request $request)
    {
        if(isset($id)){
            $constractor = Constractor::find($id);
            $this->save($constractor, $request);
            return redirect('admin/constractor/index');
        }else{
            $constractor = new Constractor;
            $this->save($constractor, $request);
            return redirect('admin/constractor/index');
        }
    }


    public function edit($id)
    {
        $edit = Constractor::find($id);
        return view('admin.constractor.create', compact('edit'));
    }



    public function destroy($id)
    {
        Constractor::find($id)->delete();
        return back();
    }


}
