<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
    public function index()
    {
        $buyers = User::where('role_id', 3)->get();
        return view('admin.buyer', compact('buyers'));
    }

    public function destory($id)
    {
        User::find($id)->delete();
        return redirect()->route('admin.dashboard');
    }

    public function seller()
    {
        $seller = User::where('role_id', 2)->get();
        return view('admin.seller', compact('seller'));
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}
