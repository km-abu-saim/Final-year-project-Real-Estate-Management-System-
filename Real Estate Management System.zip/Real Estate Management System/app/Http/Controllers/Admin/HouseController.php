<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\House;
use Illuminate\Http\Request;

class HouseController extends Controller
{
    public function index()
    {
        $houses = House::all(['id', 'name', 'status']);
        return view('admin.house.index', compact('houses'));
    }

    public function validation($request)
    {
        $request->validate([
            'name' => 'required | max:30 | min: 2',
        ]);
    }


    public function save(House $house, Request $request)
    {
        $house['name'] = $request->name;
        $house->save();
    }

    public function store($id = null, Request $request)
    {
        if (isset($id)) {
            $house = House::find($id);
            $this->validation($request);
            $this->save($house, $request);
            return back();
        } else {
            $house = new House;
            $this->validation($request);
            $this->save($house, $request);
            return back();
        }
    }

    public function edit($id)
    {
        $edit = House::find($id);
        $houses = House::all(['id', 'name', 'status']);
        return view('admin.house.index', compact('edit', 'houses'));
    }


    public function status($id)
    {
        $house = House::find($id);
        if($house->status == 1){
            $house['status'] = 0;
            $house->save();
            return back();
        }else{
            $house['status'] = 1;
            $house->save();
            return back();
        }
    }
    public function destroy($id)
    {
        house::find($id)->delete();
        return back();
    }
}
