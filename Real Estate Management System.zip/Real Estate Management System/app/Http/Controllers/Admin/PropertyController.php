<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\House;
use App\Models\Land;
use App\Models\Property;
use App\Models\PropertyApplication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class PropertyController extends Controller
{
    public function index()
    {
        $propertys = Property::all(['id', 'land_id', 'house_id', 'name', 'description', 'image', 'location', 'status']);
        return view('admin.property.index', compact('propertys'));
    }

    public function create(Request $request)
    {
        $houses = House::all(['id', 'name']);
        $lands = Land::all(['id', 'name']);
        return view('admin.property.createOrUpdate',compact('houses', 'lands'));
    }

    public function save(Request $request, Property $property)
    {
        $property['land_id'] = $request->land_id;
        $property['house_id'] = $request->house_id;
        $property['name'] = $request->name;
        $property['user_id'] = Auth::id();
        $property['location'] = $request->location;
        $property['description'] = $request->description;
        $property['price'] = $request->price;

        if($request->image){
            $path=$request->file('image')->store('/image');
        $image=$request->file('image');
             if ($image){
               $image_name=Str::random(20);
               $ext=strtolower($image->getClientOriginalExtension());
               $image_full_name=$image_name.'.'.$ext;
               $upload_path='image/';
               $image_url=$upload_path.$image_full_name;
               $success=$image->move($upload_path,$image_full_name);
                   if ($success) {
                   $property['image']=$image_url;
                }
            }
        }else{
            $property['image'] = $property->image;
        }

        $property->save();
    }

    public function store($id = null, Request $request)
    {
        if(isset($id)){
            $property = Property::find($id);
            $this->save($request, $property);
            return redirect()->route('admin.property.index');
        }else{
            $property = new Property;
            $this->save($request, $property);
            return redirect()->route('admin.property.index');
        }
    }

    public function status($id)
    {
        $property = Property::find($id);
        if($property->status == 1){
            $property['status'] = 0;
            $property->save();
            return back();
        }else{
            $property['status'] = 1;
            $property->save();
            return back();
        }
    }

    public function edit($id)
    {
        $edit = Property::find($id);
        $houses = House::all(['id', 'name']);
        $lands = Land::all(['id', 'name']);
        return view('admin.property.createOrUpdate',compact('houses', 'lands', 'edit'));
    }

    public function destroy($id)
    {
        Property::find($id)->delete();
        return back();
    }


    public function pendingPost(){
        $propertys = PropertyApplication::all();
        return view('admin.property.peding', compact('propertys'));
    }

    public function pendingPost_delete($id){
        PropertyApplication::find($id)->delete();
        return back();
    }


    public function pendingPost_update($id){
        $property = PropertyApplication::find($id);
        if($property->status == 1){
            $property['status'] = 0;
            $property->save();
            return back();
        }else{
            $property['status'] = 1;
            $property->save();
            return back();
        }
    }
}
