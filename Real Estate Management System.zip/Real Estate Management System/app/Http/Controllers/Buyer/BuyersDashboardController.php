<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\PropertyApplication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BuyersDashboardController extends Controller
{
    public function index()
    {
        $applications = PropertyApplication::where('user_id', Auth::id())->get();
        return view('buyer.index', compact('applications'));
    }
}
