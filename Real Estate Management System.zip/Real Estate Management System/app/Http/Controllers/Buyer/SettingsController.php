<?php

namespace App\Http\Controllers\Buyer;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SettingsController extends Controller
{
    public function create()
    {
        return view('buyer/profile/create');
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $user['name'] = $request->name;
        $user['email'] = $request->email;
        $user->save();
        return redirect()->route('buyer.dashboard');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('buyer.dashboard');
    }
}
